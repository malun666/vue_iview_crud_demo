<template>
  <div>
    <hr />
    <Input
      v-model="params.q"
      style="width: 300px"
      search
      enter-button
      placeholder="搜索"
      @on-search="loadData"
    />
    <hr />
    <Table :columns="columns" :data="data">
      <template slot-scope="{ row }" slot="option">
        <Button
          type="primary"
          size="small"
          style="margin-right: 5px"
          @click="$Message.info({ content: row.name })"
          >查看名字</Button
        >
        <Button
          type="error"
          size="small"
          @click="$Message.info({ content: row.id })"
          >删除ID</Button
        >
      </template>
    </Table>
    <Page
      @on-change="changePage"
      :total="total"
      :current="params._page"
      :page-size="params._limit"
    ></Page>
  </div>
</template>

<script>
import service from "../service";

export default {
  data() {
    return {
      columns: [
        {
          key: "id",
          title: "编号",
          fixed: "left"
        },
        {
          key: "name",
          title: "名字"
        },
        {
          key: "mail",
          title: "邮箱"
        },
        {
          key: "del",
          title: "编辑",
          slot: "option"
        }
      ],
      params: {
        _limit: 6,
        _page: 1,
        q: ""
      },
      total: 0,
      data: [
        {
          id: 1,
          name: "国庆睡着了"
        },
        {
          id: 2,
          name: "国庆醒了"
        }
      ]
    };
  },
  name: "home",
  created() {
    this.loadData();
  },
  methods: {
    changePage(page) {
      // this.$Message.info({ content: page });
      this.params._page = page;
      this.loadData();
    },
    loadData() {
      service.loadUser(this.params).then(res => {
        this.data = res.data;
        this.total = parseInt(res.headers["x-total-count"]);
        console.log(this.total);
      });
    }
  },
  components: {}
};
</script>
